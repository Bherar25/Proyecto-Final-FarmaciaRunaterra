package prescription;

import javax.swing.JOptionPane;

public class Selection {
    private byte persona;
    public void identificacion(){
        do {
            persona = Byte.parseByte(JOptionPane.showInputDialog(null,"¿Es usted Usuario o Funcionario? \n\n"+"1= Usuario\n2= Funcionario"));
            if((persona!=1)&&(persona!=2)){
                JOptionPane.showMessageDialog(null,"Selección incorrecta.");
            }
        }while((persona!=1)&&(persona!=2));
       
       switch (persona){
           case 1:{
               if(persona==1){
                   JOptionPane.showMessageDialog(null, "Ha seleccionado Usuario.");
                   Request Solicitud=new Request();
                   Solicitud.solicitud();
                   Solicitud.confirmacion();
               }
               break;
           }
           case 2:{
               if(persona==2){
                   JOptionPane.showMessageDialog(null, "Ha seleccionado Funcionario.");
                   Doctor Medico=new Doctor();
                   Medico.medico();
                   Medico.mostrarMenu();
               }
               break;
           }
           }
           }
       }







       
           
    
