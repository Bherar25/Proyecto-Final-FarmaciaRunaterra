package prescription;

import javax.swing.JOptionPane;

public class Main {

    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Bienvenido al sistema para confirmación de recetas.");
        JOptionPane.showMessageDialog(null, "Proceda a identificarse, por favor.");
    
        Selection Seleccion=new Selection();
        Seleccion.identificacion();
    }
}
