package prescription;

import javax.swing.JOptionPane;

public class Doctor {
    Info datosUsuario[] = new Info[5];
    private String s = "";
    private char regresar;
    
    public void medico(){
        int x;
        for (x = 0; x < datosUsuario.length; x++){
            Info crear = new Info();
            crear.setNumeroCedula("");
            crear.setNumeroReceta("");
            crear.setCompletado("");
            datosUsuario[x] = crear;
            }
        }
    
    public void llenarDatos(){
        char seguir = 's';
        int x=0;
        while (seguir == 's'){
            Info crear = new Info();
            crear.setNumeroCedula(JOptionPane.showInputDialog("Ingrese el Número de cédula del paciente: "));
            crear.setNumeroReceta(JOptionPane.showInputDialog("Ingrese el número de la receta: "));
            crear.setCompletado(JOptionPane.showInputDialog("¿Está lista la receta? (Escriba Lista o Pendiente)"));
            datosUsuario[x]=crear;
            x++;
            seguir=JOptionPane.showInputDialog(null, "¿Desea agregar otro elemento? (s= Si / n= No)").charAt(0);
                }
            }
    
    public void mostrarDatos(){
        int x;
        s="";
        for (x = 0; x < datosUsuario.length; x++){
                s = s+datosUsuario[x].getNumeroCedula()+"\n"
                    +datosUsuario[x].getNumeroReceta()+"\n"
                    +datosUsuario[x].getCompletado()+"\n\n";
            }
            JOptionPane.showMessageDialog(null, "Total de datos ingresados :\n\n"+s);
        }
    
    public void buscarDatos(){
        int x;
        String nombre = "";
        nombre = JOptionPane.showInputDialog(null, "Ingrese el Número de Receta que desea buscar: ");
        for(x = 0; x < 5; x++){
                if(nombre.equals(datosUsuario[x].getNumeroReceta())){
                    JOptionPane.showMessageDialog(null, "El dato que busca es: "+datosUsuario[x].getNumeroCedula()+"\n"+
                            "Número de receta: "+datosUsuario[x].getNumeroReceta()+"\n"+
                                    "Su estado es: "+datosUsuario[x].getCompletado());
                }
            }
        }
    
    public void confirmacion(){
        regresar = JOptionPane.showInputDialog(null, "¿Gusta editar los datos ingresados anteriormente o regresar al menú principal? (e= Editar / r = Regresar)").charAt(0);
        if(regresar=='r'){
            Selection Seleccion = new Selection();
            Seleccion.identificacion();
        }else{
            Doctor Medico=new Doctor();
                   Medico.medico();
                   Medico.mostrarMenu();
        }
    }
    public void mostrarMenu(){
        int opciones = 0;
        while(opciones!=4){
            opciones = Integer.parseInt(JOptionPane.showInputDialog(null, "Menú Funcionario\n\n"+
                    "(1) Llenar datos.\n"+
                    "(2) Mostrar datos.\n"+
                    "(3) Buscar datos.\n"+
                    "(4) Regresar al menú inicial.\n"));
            switch(opciones){
                case 1:{
                    llenarDatos();
                    break;
                }
                case 2:{
                    mostrarDatos();
                    break;
                }
                case 3:{
                    buscarDatos();
                    break;
                }
                case 4:{
                    confirmacion();
                    break;
                }
                default:{
                    JOptionPane.showMessageDialog(null, "¡Opción incorrecta!");
                }
            }
        }
    }
}


