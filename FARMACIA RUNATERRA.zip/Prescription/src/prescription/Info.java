package prescription;

public class Info {
    private String numeroCedula;
    private String numeroReceta;
    private String completado;

    public Info() {
        this.numeroCedula = "";
        this.numeroReceta = "";
        this.completado = "";
    }

    public String getNumeroCedula() {
        return numeroCedula;
    }

    public void setNumeroCedula(String numeroCedula) {
        this.numeroCedula = numeroCedula;
    }

    public String getNumeroReceta() {
        return numeroReceta;
    }

    public void setNumeroReceta(String numeroReceta) {
        this.numeroReceta = numeroReceta;
    }

    public String getCompletado() {
        return completado;
    }

    public void setCompletado(String completado) {
        this.completado = completado;
    }
    
}
