package prescription;

import javax.swing.JOptionPane;

public class Request {
    private String s="";
    private char regresar;
    char seguir = 's';
    
    Data usuario = new Data();
    
    public void solicitud(){
        
        int x=0;
        while(seguir=='s'){
            
        JOptionPane.showMessageDialog(null, "Etapa de Registro.");
        usuario.setNombre(JOptionPane.showInputDialog("Registre su nombre completo:"));
        usuario.setNumeroCedula(JOptionPane.showInputDialog("Registre su Número de cédula: (0-0000-0000)"));
        usuario.setGenero(JOptionPane.showInputDialog("Registre su Género: \n\n"+"M = Masculino\nF = Femenino").charAt(0));
        usuario.setFechaNacimiento(JOptionPane.showInputDialog("Registre su Fecha de Nacimiento: (DD/MM/AAAA)"));
        usuario.setNumeroTelefonico(JOptionPane.showInputDialog("Registre su Número Telefónico: (0000-00-00)"));
        usuario.setCorreoElectronico(JOptionPane.showInputDialog("Registre su Correo Electrónico:"));
        JOptionPane.showMessageDialog(null, 
                "Usuario: "+usuario.getNombre()+"\n\n"+
                        "Número de cédula: "+usuario.getNumeroCedula()+"\n\n"+
                                "Género: "+usuario.getGenero()+"\n\n"+
                                        "Fecha de Nacimiento: "+usuario.getFechaNacimiento()+"\n\n"+
                                                "Número Telefónico: "+usuario.getNumeroTelefonico()+"\n\n"+
                                                        "Correo Electrónico: "+usuario.getCorreoElectronico());
        seguir = JOptionPane.showInputDialog(null,"¿Desea corregir los elementos ingresados?(s= Si / n= No)").charAt(0);
        }
    }
    public void confirmacion(){
        regresar = JOptionPane.showInputDialog(null,"Hola. "+usuario.getNombre()+"\n\n"+
                "¿Gusta regresar al inicio? (s=Si / n=No)").charAt(0);
        if(regresar=='n'){
            Selection Seleccion = new Selection();
            Seleccion.identificacion();
        }else{
            seguir = JOptionPane.showInputDialog(null,"¿Desea corregir los elementos ingresados?(s= Si / n= No)").charAt(0);
            Request Solicitud=new Request();
                   Solicitud.solicitud();
                   Solicitud.confirmacion();
        }
    }
}
